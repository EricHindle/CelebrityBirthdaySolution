﻿Namespace TwitterVB2
    Public Class Status

    End Class
End Namespace
